/* Northern Soul — shared motion layer.
   Progressive enhancement: markup paints first, JS decorates after mount.
   Idempotent, picks up nodes added later via MutationObserver. */
(function () {
  if (window.__nsrMotion) return;
  window.__nsrMotion = true;

  var reduced = false;
  try { reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) {}

  var EASE = 'cubic-bezier(.16,1,.3,1)';
  var parallaxNodes = [];
  var headerUtil = null, headerMain = null;
  var bar = null;

  /* ---------- scroll progress ---------- */
  function ensureBar() {
    if (bar) return;
    bar = document.createElement('div');
    bar.setAttribute('data-nsr-progress', '');
    bar.style.cssText = 'position:fixed;top:0;left:0;height:2px;width:0%;background:#1B4DE4;z-index:9999;pointer-events:none;transition:width 90ms linear';
    document.body.appendChild(bar);
  }

  /* ---------- reveal ---------- */
  /* Writing the end values is not enough on its own: if a transition is attached to a
     property but never ticks, it holds the from-value and the element stays invisible.
     `hard` drops the transition and forces a reflow first, which always commits. */
  function reveal(el, hard) {
    if (hard) {
      el.style.transition = 'none';
      void el.offsetHeight;
    }
    el.style.opacity = '1';
    el.style.transform = 'none';
    el.style.clipPath = 'inset(0% 0% 0% 0%)';
    el.style.filter = 'none';
    el.__nsrRevealed = true;
    setTimeout(function () { el.style.willChange = 'auto'; }, hard ? 0 : 1100);
  }

  var io = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      var el = en.target;
      io.unobserve(el);
      var delay = parseInt(el.getAttribute('data-reveal-delay') || '0', 10);
      setTimeout(function () {
        reveal(el, false);
        // If the transition never ticks, the values above won't commit. Verify and force.
        setTimeout(function () {
          if (el.__nsrRevealed && getComputedStyle(el).opacity !== '1') reveal(el, true);
        }, 120);
      }, delay);
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -6% 0px' }) : null;

  function prepReveal(el) {
    if (el.__nsrReveal) return;
    el.__nsrReveal = true;
    var kind = el.getAttribute('data-reveal') || 'up';
    if (reduced || !io) return;
    var t = 'opacity 820ms ' + EASE + ', transform 900ms ' + EASE + ', clip-path 1050ms ' + EASE + ', filter 900ms ' + EASE;
    el.style.willChange = 'opacity, transform';
    el.style.transition = t;
    if (kind === 'wipe') {
      el.style.clipPath = 'inset(0% 0% 100% 0%)';
      el.style.transform = 'scale(1.04)';
    } else if (kind === 'fade') {
      el.style.opacity = '0';
    } else if (kind === 'right') {
      el.style.opacity = '0';
      el.style.transform = 'translate3d(-26px,0,0)';
    } else if (kind === 'blur') {
      el.style.opacity = '0';
      el.style.filter = 'blur(10px)';
      el.style.transform = 'translate3d(0,18px,0)';
    } else {
      el.style.opacity = '0';
      el.style.transform = 'translate3d(0,30px,0)';
    }
    io.observe(el);
    // Safety net: nothing stays hidden because an observer never fired or a transition stalled.
    setTimeout(function () {
      if (getComputedStyle(el).opacity === '1' && el.__nsrRevealed) return;
      if (io) io.unobserve(el);
      reveal(el, true);
    }, 3000);
  }

  /* ---------- count up ---------- */
  var countIO = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (!en.isIntersecting) return;
      var el = en.target;
      countIO.unobserve(el);
      var target = parseFloat(el.getAttribute('data-count'));
      var pre = el.getAttribute('data-count-pre') || '';
      var post = el.getAttribute('data-count-post') || '';
      if (reduced || !isFinite(target)) return;
      var dur = 1400, t0 = null;
      function step(ts) {
        if (t0 === null) t0 = ts;
        var p = Math.min(1, (ts - t0) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = pre + Math.round(target * eased) + post;
        if (p < 1) requestAnimationFrame(step);
        else el.textContent = pre + target + post;
      }
      el.textContent = pre + '0' + post;
      requestAnimationFrame(step);
    });
  }, { threshold: 0.4 }) : null;

  /* The authored value always stays in the DOM; the observer only borrows it to animate. */
  function prepCount(el) {
    if (el.__nsrCount) return;
    var target = parseFloat(el.getAttribute('data-count'));
    if (!isFinite(target)) return;
    el.__nsrCount = true;
    var pre = el.getAttribute('data-count-pre') || '';
    var post = el.getAttribute('data-count-post') || '';
    el.textContent = pre + target + post;
    if (countIO) countIO.observe(el);
  }

  /* ---------- magnetic buttons ---------- */
  function prepMagnetic(el) {
    if (el.__nsrMag || reduced) return;
    el.__nsrMag = true;
    el.style.transition = 'transform 420ms ' + EASE + ', background 260ms ease, color 260ms ease';
    el.addEventListener('mousemove', function (e) {
      var r = el.getBoundingClientRect();
      var dx = (e.clientX - (r.left + r.width / 2)) / r.width;
      var dy = (e.clientY - (r.top + r.height / 2)) / r.height;
      el.style.transition = 'transform 120ms linear, background 260ms ease, color 260ms ease';
      el.style.transform = 'translate3d(' + (dx * 10).toFixed(2) + 'px,' + (dy * 7).toFixed(2) + 'px,0)';
    });
    el.addEventListener('mouseleave', function () {
      el.style.transition = 'transform 620ms ' + EASE + ', background 260ms ease, color 260ms ease';
      el.style.transform = 'translate3d(0,0,0)';
    });
  }

  /* ---------- accordion ---------- */
  function prepAcc(el) {
    if (el.__nsrAcc) return;
    var btn = el.querySelector('[data-acc-btn]');
    var panel = el.querySelector('[data-acc-panel]');
    var icon = el.querySelector('[data-acc-icon]');
    if (!btn || !panel) return; // still streaming — leave unmarked so a later scan picks it up
    el.__nsrAcc = true;
    panel.style.overflow = 'hidden';
    panel.style.maxHeight = '0px';
    panel.style.opacity = '0';
    panel.style.transition = 'max-height 520ms ' + EASE + ', opacity 380ms ease';
    if (icon) icon.style.transition = 'transform 460ms ' + EASE;
    btn.style.cursor = 'pointer';
    btn.addEventListener('click', function () {
      var open = panel.style.maxHeight !== '0px';
      var group = el.parentNode ? el.parentNode.querySelectorAll('[data-acc]') : [];
      Array.prototype.forEach.call(group, function (other) {
        if (other === el) return;
        var op = other.querySelector('[data-acc-panel]');
        var oi = other.querySelector('[data-acc-icon]');
        if (op) { op.style.maxHeight = '0px'; op.style.opacity = '0'; }
        if (oi) oi.style.transform = 'rotate(0deg)';
      });
      if (open) {
        panel.style.maxHeight = '0px';
        panel.style.opacity = '0';
        if (icon) icon.style.transform = 'rotate(0deg)';
      } else {
        panel.style.maxHeight = panel.scrollHeight + 40 + 'px';
        panel.style.opacity = '1';
        if (icon) icon.style.transform = 'rotate(135deg)';
      }
    });
  }

  /* ---------- hover lift ---------- */
  function prepLift(el) {
    if (el.__nsrLift || reduced) return;
    el.__nsrLift = true;
    var prev = el.style.transition;
    el.style.transition = (prev ? prev + ', ' : '') + 'transform 620ms ' + EASE + ', box-shadow 620ms ' + EASE;
    el.addEventListener('mouseenter', function () {
      el.style.transform = 'translate3d(0,-6px,0)';
      el.style.boxShadow = '0 24px 60px -30px rgba(11,13,16,.55)';
    });
    el.addEventListener('mouseleave', function () {
      el.style.transform = 'translate3d(0,0,0)';
      el.style.boxShadow = 'none';
    });
  }

  /* ---------- scroll loop ---------- */
  var ticking = false;
  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(function () {
      ticking = false;
      var y = window.pageYOffset || document.documentElement.scrollTop || 0;
      var doc = document.documentElement;
      var max = doc.scrollHeight - window.innerHeight;
      if (bar) bar.style.width = (max > 0 ? Math.min(100, (y / max) * 100) : 0) + '%';

      if (headerUtil) {
        var shrunk = y > 60;
        headerUtil.style.transition = 'max-height 480ms ' + EASE + ', opacity 300ms ease';
        headerUtil.style.overflow = 'hidden';
        headerUtil.style.maxHeight = shrunk ? '0px' : '60px';
        headerUtil.style.opacity = shrunk ? '0' : '1';
      }
      if (headerMain) {
        headerMain.style.transition = 'box-shadow 400ms ease';
        headerMain.style.boxShadow = y > 60 ? '0 12px 40px -28px rgba(11,13,16,.5)' : 'none';
      }

      if (!reduced) {
        for (var i = 0; i < parallaxNodes.length; i++) {
          var n = parallaxNodes[i];
          var r = n.getBoundingClientRect();
          if (r.bottom < -200 || r.top > window.innerHeight + 200) continue;
          var amt = parseFloat(n.getAttribute('data-parallax')) || 0.12;
          var mid = r.top + r.height / 2 - window.innerHeight / 2;
          n.style.transform = 'translate3d(0,' + (-mid * amt).toFixed(1) + 'px,0)';
        }
      }
    });
  }

  function scan() {
    ensureBar();
    var q = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
    q('[data-reveal]').forEach(prepReveal);
    q('[data-count]').forEach(prepCount);
    q('[data-magnetic]').forEach(prepMagnetic);
    q('[data-acc]').forEach(prepAcc);
    q('[data-lift]').forEach(prepLift);
    q('[data-parallax]').forEach(function (n) {
      if (n.__nsrPar) return;
      n.__nsrPar = true;
      n.style.willChange = 'transform';
      parallaxNodes.push(n);
    });
    headerUtil = document.querySelector('[data-header-util]') || headerUtil;
    headerMain = document.querySelector('[data-header-main]') || headerMain;
    onScroll();
  }

  function boot() {
    scan();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    if ('MutationObserver' in window) {
      var mo = new MutationObserver(function () {
        clearTimeout(window.__nsrScanT);
        window.__nsrScanT = setTimeout(scan, 80);
      });
      mo.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
