# Handoff: Northern Soul Renovation — brand refresh + full site rebuild

## Overview

A complete rebrand and website redesign for **Northern Soul Renovation**, a family-run design–build contractor serving Greater Vancouver and the Fraser Valley (residential remodels, commercial build-outs, and specialist microcement finishes).

The package covers a new visual identity (wordmark, mark, palette, type system, voice) and six pages: Home, Services, Projects, About, Estimate, plus a Brand Kit reference document.

Replaces the current Squarespace site at northernsoulrenovation.com.

**Primary business goal is lead generation.** Every page funnels to the estimate flow or the phone number. Treat the estimate form and the click-to-call links as the highest-priority functionality.

---

## About the design files

The files in this bundle are **design references written in HTML** — prototypes that demonstrate intended layout, styling, copy, and behavior. They are **not production code to copy directly.**

They were authored in a component format that inlines all styling (no stylesheets, no class names) so the design could stream and render progressively in the design tool. **Do not carry that constraint into production.** Your job is to recreate these designs in the target codebase using its own conventions — a proper stylesheet or CSS-in-JS layer, real components, a design-token file.

Recommended stack if none exists yet: **Astro** or **Next.js (static export)** with real `<Image>` optimization. This is a marketing site — it should ship as mostly static HTML, score well on Core Web Vitals, and be editable by a non-developer. A headless CMS or MDX for projects/services content is worth the setup; the client will want to add projects without a deploy.

### Structural note on the prototypes

Each `.dc.html` file is one page. The page body sits between `<x-dc>` tags; ignore the surrounding document scaffolding, the `<script data-dc-script>` block's `data-props` JSON, and the `support.js` reference — those are tooling artifacts.

Two patterns to translate:
- `<dc-import name="NSRHeader" active="home">` mounts the shared header component with an `active` prop that controls which nav item shows its underline. `<dc-import name="NSRFooter">` mounts the footer. Build these as two shared components.
- `{{ someName }}` is a template hole filled at runtime by the `renderVals()` method in the file's logic class. These mark the genuinely dynamic values (before/after slider position, FAQ open state, estimate form step). Everything else is static.

---

## Fidelity

**High fidelity.** Colors, typography, spacing, copy, and interaction timing are all final and intentional. Recreate pixel-accurately.

Two things are deliberately *not* final and need client input before launch:
1. **Testimonials** — the three quotes on the homepage are realistic placeholders. Replace with real Google reviews.
2. **The "5.0 Google" rating tile** — unverified. Confirm the real rating and review count, or pull it live from the Google Places API.

---

## Design tokens

### Color

| Token | Hex | oklch | Use |
|---|---|---|---|
| Ink | `#0B0D10` | `oklch(0.19 0.008 260)` | Body text, dark section grounds, footer |
| Signal Blue | `#1B4DE4` | `oklch(0.52 0.22 264)` | CTAs, links, accents, active states |
| Beam Blue | `#7FA0FF` | `oklch(0.73 0.13 266)` | Accent on dark grounds only — never on white |
| Concrete | `#F2F3F5` | `oklch(0.96 0.003 260)` | Alternating section backgrounds |
| Paper | `#FFFFFF` | — | Primary background |
| Body grey | `#5A616C` | — | Paragraph text on light |
| Muted grey | `#8A909B` | — | Captions, metadata on light |
| Light grey | `#C9D1E0` | — | Paragraph text on ink |
| Dim grey | `#8B93A3` | — | Secondary text on ink |
| Hairline (light) | `#E3E5EA` | — | Borders and grid lines on white |
| Hairline (concrete) | `#DCDEE3` / `#C9CDD4` | — | Borders on concrete sections |
| Hairline (dark) | `#1C1F26` | — | Borders on ink sections |
| Input border | `#D6D9DF` | — | Form fields |
| Pale blue | `#E8EDFB` | — | Selected chip background |
| CTA text on blue | `#DCE5FF` / `#C7D5FF` | — | Paragraph/caption on Signal Blue |

**Usage ratio: paper 60 / ink 20 / concrete 13 / signal blue 7.** Signal Blue is an accent — one thing at a time, never a background wash. The only full-blue sections are the final CTA bands.

Contrast: Signal Blue on white is 6.5:1; white on Signal Blue is 6.5:1. Both pass AA.

### Typography

Two families. Both from Google Fonts.

```
https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,100..900&family=Instrument+Sans:wght@400;500;600;700&display=swap
```

**Archivo (variable, width axis)** — display only.
- Always `text-transform: uppercase`
- `font-stretch: 112%–125%` (expanded). 118–122% is the default for headings; 125% for the largest numerals and the footer wordmark.
- `font-weight: 700`
- `letter-spacing: -0.02em` to `-0.025em`
- `line-height: 0.90–0.96`

**Instrument Sans** — everything else.
- Body: 15–19px, `line-height` 1.65–1.75, `text-wrap: pretty`
- Buttons and nav: 14.5–15px, weight 600, **sentence case, no letter-spacing**
- Captions/metadata: 13.5–14px, weight 500

**Critical:** there is no monospace, no tracked-out uppercase micro-labeling, and no `01 / 02 / 03` numbering anywhere in this design. An earlier revision had them and they were removed on purpose — they made the site read as templated. Do not reintroduce them.

The one exception is the logotype's second line ("RENOVATION"), which is intentionally letter-spaced at `0.42em` at 9.5–10px. That is a logotype detail, not a label style.

### Type scale (fluid)

| Role | Size |
|---|---|
| Hero H1 | `clamp(42px, 8.2vw, 124px)` / lh 0.90 |
| Page H1 | `clamp(40px, 7vw, 104px)` / lh 0.90 |
| Section H2 (large) | `clamp(34px, 5.2vw, 76px)` / lh 0.94 |
| Section H2 (medium) | `clamp(32px, 4.4vw, 62px)` / lh 0.94 |
| Subsection H2 | `clamp(30px, 3.8vw, 54px)` / lh 0.96 |
| Card H3 | `clamp(22px, 2.1vw, 29px)` / lh 1.05 |
| Lead paragraph | `clamp(16px, 1.35vw, 19px)` / lh 1.65 |
| Body | 15.5–16px / lh 1.65–1.7 |
| Caption | 13.5–14px |

### Spacing & layout

- Page container: `max-width: 1480px`, `margin: 0 auto`
- Gutter: `padding: 0 clamp(16px, 4vw, 56px)`
- Section vertical rhythm: `clamp(64px, 8vw, 130px)` for major sections, `clamp(56px, 7vw, 110px)` for secondary
- **Border radius: 0 everywhere.** Sharp corners are core to the identity. No rounded cards, no pill buttons.
- Grid lines are achieved with a 1px `gap` over a hairline-colored parent background — reproduce with real borders if cleaner in your stack
- Responsive without media queries: `repeat(auto-fit, minmax(Npx, 1fr))` throughout. You may convert to media queries, but preserve the breakpoints those minimums imply.

### Motion

All timings use `cubic-bezier(.16, 1, .3, 1)` unless noted.

| Effect | Spec |
|---|---|
| Scroll reveal (rise) | `opacity 0→1`, `translateY(30px)→0`, 820/900ms, IO threshold 0.08, rootMargin `0px 0px -6% 0px` |
| Scroll reveal (wipe) | `clip-path: inset(0 0 100% 0)` → `inset(0 0 0 0)` + `scale(1.04)→1`, 1050ms |
| Stagger | 70–90ms between siblings |
| Image hover zoom | `scale(1.04–1.06)`, 700–800ms, `cubic-bezier(.2,.7,.2,1)` |
| Card lift | `translateY(-6px)` + `0 24px 60px -30px rgba(11,13,16,.55)`, 620ms |
| Magnetic buttons | Cursor-proportional `translate` up to 10px x / 7px y, 120ms in, 620ms release |
| Hero entrance | Staggered rise at 80 / 200 / 380 / 520 / 660ms |
| Hero image | `scale(1.14)→1` over 2600ms + `0.07` scroll parallax |
| Accordion | `max-height 0→600px` 560ms, `opacity` 400ms, icon `rotate(0→135deg)` 460ms |
| Counters | 1400ms, cubic ease-out |
| Header condense | Utility bar `max-height 60px→0` + fade at `scrollY > 60`, 480ms |
| Marquee | `translateX(0 → -50%)`, 42s linear infinite |

**All of it must be wrapped in `prefers-reduced-motion: reduce`.** See `motion.js` for the reference implementation — it is plain, dependency-free, and can be ported or replaced with your animation library of choice.

Two implementation warnings learned the hard way:
1. **Never blank authored text to animate it.** The counters read their target from a `data-count` attribute but keep the real value in the DOM; the observer only borrows it. If the observer never fires, the number is still correct.
2. **Don't drive component state by writing inline styles from an external script** — the framework will wipe them on re-render. The FAQ accordion is component state for exactly this reason.

---

## Screens

### Shared: Header (`NSRHeader.dc.html`)

Sticky, `z-index: 80`. Two stacked bars.

**Utility bar** — ink background, 10px vertical padding, 13.5px text.
Left: "Greater Vancouver & the Fraser Valley" (`#C9D1E0`). Right: "Free written scope in 48 hrs" and "Family-run since 2019" (`#6E7A8C`), 22px gap.
Collapses to zero height on scroll past 60px.

**Main bar** — white, `min-height: 74px`, 1px bottom border `#E3E5EA`, `box-shadow: 0 12px 40px -28px rgba(11,13,16,.5)` when scrolled.
- **Left:** logo lockup — the three-beam mark (26×30px) + "NORTHERN SOUL" (Archivo 118% / 700 / 15px / `0.1em`) over "RENOVATION" (Instrument Sans 9.5px / `0.42em` / `#6E7686`), 12px gap
- **Center:** Services / Projects / About — 14.5px, weight 500, ink, hover `#1B4DE4`, `gap: clamp(14px, 1.9vw, 30px)`. Active page gets a 2px `#1B4DE4` underline bar. (Process and FAQ were removed from the nav to keep it on one line; they remain in the footer.)
- **Right:** phone `1-877-455-1811` (15.5px / 600 / `white-space: nowrap`) and a Signal Blue "Free estimate →" button (14px 22px padding, 14.5px / 600, hover → ink). Magnetic.

**The mark:** three parallelograms, each 22% of the container width, at `left: 0 / 39% / 78%`, full height, `transform: skewX(-16deg)`. Colors left→right: ink (or white when reversed), `#1B4DE4`, `#7FA0FF`. It's the aurora the company is named after — founder Norbert's name means Northern Lights. Ship as SVG in production.

### Shared: Footer (`NSRFooter.dc.html`)

Ink background. `padding: clamp(56px,7vw,96px) → 0`.
Four columns, `repeat(auto-fit, minmax(220px, 1fr))`, `gap: clamp(32px,4vw,56px)`:
1. Reversed logo lockup, boilerplate paragraph (`#8B93A3`, max 32ch), Instagram + Facebook outline buttons (1px `#23262E`, hover border `#1B4DE4`)
2. **Services** — six links to Services page anchors
3. **Company** — Our work, About the family, How a build runs, Reviews, Service areas, FAQ
4. **Get in touch** — phone at `clamp(20px,2.2vw,26px)` Archivo, email, hours, location, "Book a consult →" button

Below: an oversized "NORTHERN SOUL" in Archivo 125% at `clamp(40px, 12.5vw, 190px)`, color `#14171D` (barely above the ink ground), `white-space: nowrap`, clipped by `overflow: hidden`. Then a hairline and a three-part legal row.

### Home (`Home.dc.html`)

1. **Hero** — full-bleed photo on ink, two gradient scrims (`100deg` horizontal 0.94→0.35, `180deg` vertical). Star row + trust line, H1 "RENOVATIONS WITH SOUL. **BUILT TO LAST.**" (second sentence in `#7FA0FF`), lead paragraph, two CTAs, three trust points. Staggered entrance; image has ken-burns + parallax.
2. **Stat bar** — ink, four cells divided by vertical hairlines: **2019** / Family-run since · **48 HRS** / To your written scope · **ONE LEAD** / Your contact, whole build · **TURN-KEY** / Design, build & finish. First two count up.
3. **Marquee** — Signal Blue band, 15px padding, repeating: Soul ◆ Beauty ◆ Craft ◆ Design. Build. Evolve. ◆ Licensed & insured ◆ Family-run since 2019 ◆ Greater Vancouver ◆ Fraser Valley. Duplicate the group and translate −50% for a seamless loop. `aria-hidden`.
4. **Services** — H2 "SIX WAYS WE CHANGE A SPACE." + intro. Six cards in a hairline grid (`minmax(320px,1fr)`), each: 4:3 image (hover zoom), H3, paragraph. Whole card links to the matching Services anchor. Cards: Kitchen remodels, Bathroom remodels, Microcement, Residential renovations, Commercial build-outs, Design & planning.
5. **Before / after** — concrete ground. H2 "DATED GALLEY, OPENED INTO ONE ROOM." Interactive 16:9 comparison: after-photo base layer, before-photo clipped by `inset(0 {100-split}% 0 0)`, 2px white divider with a 52×52 white handle (pulsing). Scrubs on `mousemove`, drags on pointer. Clamped 2–98%. "Before" and "After" chips bottom-left/right. Four stats below: Wall out / Full gut / One list / Fixed price.
6. **Selected work** — H2 + "All projects →". Four 3:4 tiles, wipe-reveal with stagger, lift on hover, each with a hairline caption row (title left, location right).
7. **Process** — ink. H2 "HOW A BUILD ACTUALLY RUNS." 2×2 grid (`minmax(310px,1fr)`): The walkthrough / Design & selections / Build / Handover. Each has a paragraph and a bordered footnote line. **No step numbers** — order is positional.
8. **Reviews** — a four-cell strip (Signal Blue "5.0 Google" tile + Referred / Repeated / Reviewed), then three bordered testimonial cards with star row, Archivo 105% quote, and a hairline attribution footer.
9. **Why people hire us** — split: full-bleed site photo on one side, "A FAMILY NAME ON EVERY JOB SITE." with three hairline-divided points on the other (scope that doesn't move / one number for the whole build / we come back).
10. **Service areas** — H2 "WHERE WE BUILD." plus a hairline grid of 17 municipalities and a "Not listed? Ask →" cell in ink.
11. **FAQ** — concrete. Sticky-feeling two-column: heading + phone on the left, six-item accordion on the right. One open at a time, first open by default. "+" rotates 135° to an ×.
12. **Final CTA** — full Signal Blue band. "TELL US ABOUT THE SPACE." + "Start my estimate →" and the phone number.

### Services (`Services.dc.html`)

Ink hero with H1 "EVERYTHING BETWEEN THE DRAWING AND THE FINAL COAT." and six anchor chips.

Six alternating full-width sections (white / concrete / **ink for microcement** / white / concrete / white), image and text swapping sides each time. Each: 4:5 image, H2, paragraph, a six-cell hairline grid of inclusions, and a text CTA. Microcement is the ink-grounded section — it's the differentiator and should feel like the feature.

Closes with a Signal Blue CTA band.

### Projects (`Projects.dc.html`)

Ink hero. A filter chip row (All work / Commercial / Residential / Bathrooms / Microcement / Kitchens) — currently anchor jumps; **implement as real filtering** when the project list becomes CMS-driven.

One featured 21:9 project (Alive Fitness & Wellness) with a four-cell spec strip below (Type / Location / Scope / Delivery), then a six-up grid of projects, each with a 4:3 image, hairline caption row, and a one-line description.

Closes with a photography note and a "Request the full portfolio →" CTA.

### About (`About.dc.html`)

Ink hero + a full-bleed band photo. Then:
- **Mission** — split heading/body on white
- **The people on your job** — two large 4:5 portraits side by side (`minmax(330px,1fr)`), name in Archivo `clamp(24px,2.6vw,36px)`, role line at 17px, then a paragraph. Below a hairline: "AND THE SAME CREW BEHIND THEM." with a five-row table of disciplines marked *In house* / *Long-standing partners* / *Handled by us*
- **Values** — ink, three cells: Soul / Beauty / Craft
- **Quote** — "Great things come from construction zones, not comfort zones." in Archivo `clamp(26px,4.2vw,60px)`
- Signal Blue CTA band

### Estimate (`Estimate.dc.html`)

Ink hero. Two columns:

**Left — the form.** A three-segment progress bar (fills Signal Blue as you advance), then:
- **Step 1:** "What are we building?" — six selectable chips (Kitchen remodel / Bathroom remodel / Whole home or suite / Commercial build-out / Microcement / Design only). Selected = `#E8EDFB` fill + `#1B4DE4` border. Default Kitchen remodel.
- **Step 2:** Budget range (6 options incl. "Not sure yet — advise me"), start timing (4), city, and whether drawings exist (3)
- **Step 3:** Name, phone, email, notes + "Send my request →"
- **Confirmation:** Signal Blue checkmark tile, "REQUEST RECEIVED.", and a call button

Back/Continue buttons on steps 2–3. Inputs: 16px padding, 1px `#D6D9DF`, zero radius, `outline: 2px solid #1B4DE4; outline-offset: -2px` on focus.

**Right —** a 4:3 photo, a three-step "What happens next" list, and an ink contact card.

**Production requirements:** wire to the client's inbox/CRM, add a honeypot field, validate email and phone, keep partial state if the user navigates away, and fire a conversion event on submit. Consider persisting step state to `sessionStorage`.

### Brand Kit (`Brand Kit.dc.html`)

An internal reference document, not a public page. Cover, logo lockups (horizontal / reversed / stacked / mark-only at three sizes), clear space and minimum size rules, the color system with usage ratio bar, type specimens, voice do/don't plus boilerplate, and four application mockups (business card, social tile, project photography with caption plate, site hoarding).

Ship this as a downloadable PDF for the client rather than a live route. Its annotation labels are the one place small captions are appropriate — it's a spec document.

---

## Interactions & behavior

| Element | Behavior |
|---|---|
| Header | Sticky; utility bar collapses past 60px scroll; shadow appears |
| Scroll progress | 2px Signal Blue bar, fixed top, `z-index: 9999` |
| Nav links | Color shift to `#1B4DE4` on hover; active page underlined |
| CTA buttons | Magnetic follow; primary inverts to ink on hover, on-ink buttons invert to white |
| Service/project cards | Image zooms; project tiles also lift with a shadow |
| Before/after | Hover-scrub and pointer-drag, clamped 2–98% |
| FAQ | Single-open accordion, first item open, animated height, icon rotates |
| Estimate form | Three steps + confirmation, chip selection, progress bar |
| Anchor links | `scroll-behavior: smooth` on `html` |
| Reduced motion | All animation and transition durations collapse to ~0 |

---

## State

Only three pieces of real state:

1. **Before/after split** (Home) — number, 2–98, default 52. Drives the before layer's `clip-path` and the handle's `left`.
2. **FAQ open index** (Home) — 1–6 or 0 for all closed, default 1. Drives `max-height`, `opacity`, and icon `transform` per item.
3. **Estimate form** — `step` (1–3), `type` (string, default "Kitchen remodel"), `done` (boolean). Field values are currently uncontrolled and must become controlled and validated in production.

Everything else is static content and belongs in a CMS or content files.

---

## Assets

### Included in this bundle (`assets/`)

| File | Use |
|---|---|
| `microcement-wetroom.png` | Services microcement section (4:5) + Projects tile |
| `microcement-wall-floor.png` | Home microcement service card (4:3) |
| `kitchen-before.png` | Home before/after — the "before" layer (16:9) |
| `michelle.png` | About — Michelle Amaba portrait |

The first three are AI-generated stand-ins the client approved. **Replace with real project photography when available** — particularly `kitchen-before.png`, which should ideally be shot from the same position as the finished kitchen so the slider lines up.

### Referenced from the client's existing Squarespace CDN

The prototypes hotlink twelve photos from `images.squarespace-cdn.com/content/v1/66727dfb02d9063005de9166/…`. **These must be downloaded, optimized, and re-hosted** — the CDN URLs will break when the Squarespace subscription lapses.

Verified photo subjects (several were mislabeled in the original site's filenames, so trust this list over the filename):

| File | Actual subject | Used as |
|---|---|---|
| `Copy+of+DSC07512.jpg` | Dim interior | Home hero |
| `PANG001.jpg` | Kitchen, island + fridge | Kitchen service card, Services kitchens, Projects "Pang residence" |
| `Copy+of+DSC07451.jpg` | Bathroom, shower fixture | Bathroom service card, Services bathrooms, Projects "Shower & wet area" |
| `Copy+of+DSC07421.jpg` | Lit-mirror vanity | Home work grid, Projects "Vanity & ensuite", Estimate |
| `PANG006.jpg` | Kitchen, shaker cabinets | Before/after "after" layer, Projects "Kitchen & pantry" |
| `KR-AIRBNB-BR1-1.JPG` | Bedroom | Residential service card, Projects "Downtown suite" |
| `gym.png` | Fitness studio | Commercial service card, Projects featured |
| `NSR-ALG-017.jpg` | — | Design & planning service card |
| `Copy+of+DSC07600+(1).jpg` | — | About band, Home "why people hire us" |
| `Image+2023-05-19+at+10.18+AM+(1).jpg` | Portrait | About — Norbert |

`NORTHERN+SOUL+RENOVATION.jpg` and `DSC08293.jpg` from the old site are **deliberately unused** — the first is a mood board with the old logo printed on it, the second a studio headshot that can't stand in for a crew shot.

### Still needed from the client

- Real Google reviews to replace the three placeholder testimonials
- Verified Google rating and review count
- A vector version of the new mark for print, vehicle livery, and favicon

---

## Files in this bundle

| File | Contents |
|---|---|
| `Home.dc.html` | Homepage — the fullest expression of the system |
| `Services.dc.html` | Six service sections |
| `Projects.dc.html` | Portfolio |
| `About.dc.html` | Story, team, values |
| `Estimate.dc.html` | Multi-step lead form |
| `Brand Kit.dc.html` | Identity reference document |
| `NSRHeader.dc.html` | Shared header |
| `NSRFooter.dc.html` | Shared footer |
| `motion.js` | Reference implementation of the scroll/reveal/parallax/magnetic layer |
| `assets/` | New photography and the Michelle portrait |

Open any `.dc.html` directly in a browser to see it running.

---

## SEO & launch notes

Not styled in the prototypes, but required:

- Page titles and meta descriptions per page, targeting "renovation contractor Vancouver / Surrey", "microcement Vancouver", "kitchen renovation Fraser Valley"
- `LocalBusiness` + `Service` JSON-LD with NAP, service area, and hours
- Redirect map from the old Squarespace URLs — note the current services page lives at `/services-4`
- Real `alt` text on every image (the prototypes have descriptive alt already; keep it)
- `tel:` links on every phone number (already in place)
- Open Graph image using the new stacked lockup on ink
